import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import Navbar from './Navbar';
import Movie from './Movie';
import List from './List'
import {Route, Routes, Link, Router, Outlet} from 'react-router-dom';
 
const Home=()=>{
    return (
        <div className='home'>
            <Navbar/>
            <Movie/>
            <List/>
 
            <img src='https://www.freepnglogos.com/uploads/black-netflix-logo-png-4.png' alt='footer' className='footer'/>
 
 
        </div>
    )
}
 
export default Home;