import './Description3.css'

import React from 'react';
import ReactDOM from 'react-dom';

import Navbar from './Navbar';
const Description3=()=>{
    return(
        <div className="main-containter3">
            <div className="navbar">
                <Navbar/>
            </div>
            <div className="movieinfo">
                <h1> BROOKLYN NINE NINE </h1>
                <div className="percent">
                    <h4> 98% match  &nbsp; &nbsp;</h4>
                    <span>2013</span>
                </div>
                <div className="buttons">
                    <button className='play'><img src='https://cdn-icons-png.flaticon.com/512/0/375.png'alt='play'/>
                    <span className='spanplay'> &nbsp; Play</span>
                    </button>

                    <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/1828/1828926.png' alt='info'/>
                    <span className='mylist'> &nbsp; My List</span>
                    </button>
 
                </div>
                <h3> Ray Holt, an eccentric commanding officer, <br/> and his diverse and quirky team of odd <br/>detectives solve crimes in Brooklyn, New York City.</h3>
                <p> Cast: Andy Samberg, Melissa Fumero, Sthepanie Beatriz<br/>
                Creators:  Dan Goor, Michael Schur</p>
<br/>
                <div className="rate">
                    <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/126/126473.png'alt='play'/>
                    </button> <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/20/20661.png' alt='info'/>
                    </button>
                </div>

            </div>
        </div>
        
    )

}
export default Description3;





