import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './Listitem3.css';
import {Link, Outlet} from 'react-router-dom'

const Listitem3=()=>{
    return (
        <div className='listitem'>
            <img src='https://storage.googleapis.com/cdn.spoilertv.com/images/headers/bojack-horseman.jpg' alt='' className='spider'/>
        </div>
    )
}
 
export default Listitem3;

