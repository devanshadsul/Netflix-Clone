import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './List.css';
import Listitem from './Listitem';
import Listitem2 from './Listitem2';
import Listitem3 from './Listitem3';
import Listitem4 from './Listitem4';
import Listitem5 from './Listitem5';
import Listitem6 from './Listitem6';
 
const List=()=>{
    return (
        <div className='list'>
            <span className='listTitle'>Continue Watching</span>
            <div className="wrapper">
                <img src='https://www.freeiconspng.com/uploads/arrow-icon--myiconfinder-23.png' alt='back' className='sliderArrow left'/>
                <div className='container'>
                <Listitem/>
                <Listitem2/>
                <Listitem3/>
                <Listitem4/>
                <Listitem5/>
                <Listitem6/>
                </div>
                <img src='https://www.freeiconspng.com/uploads/line-png-32.png' alt='forward' className='sliderArrow right'/>
            </div>
 
 
        </div>
    )
}
 
export default List;

