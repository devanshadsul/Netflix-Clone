import './Description.css'

import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Outlet} from 'react-router-dom';

import Navbar from './Navbar';
const Description=()=>{
    // const onClickSubmit=(event)=>{
    //     <a href='https://youtu.be/_MoIr7811Bs'></a>
    // }
    return(
        <div className="main-containter1">
            <div className="navbar">
                <Navbar/>
            </div>
            <div className="movieinfo">
                <h1> SHREK </h1>
                <div className="percent">
                    <h4> 58% match  &nbsp; &nbsp;</h4>
                    <span>2012</span>
                </div>
                <div className="buttons">
                    <button className='play' ><img src='https://www.freeiconspng.com/uploads/video-play-icon-6.png'alt='play'/>
                    <span className='spanplay'> &nbsp; Play</span>
                    </button>

                    <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/1828/1828926.png' alt='info'/>
                    <span className='mylist'> &nbsp; My List</span>
                    </button>
 
                </div>
                <h3> Shrek, an ogre, embarks on a journey with a donkey to <br/> rescue Princess Fiona from a vile lord and regain his swamp.</h3>
                <p> Cast: Mike Myers, Eddie Murphy, Cameron Diaz<br/>
                Director: Andrew Adamson, Vicky Jenson</p>
<br/>
                <div className="rate">
                    <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/126/126473.png'alt='play'/>
                    </button> <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/20/20661.png' alt='info'/>
                    </button>
                </div>

            </div>
        </div>
        
    )

}
export default Description;





