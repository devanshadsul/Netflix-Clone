import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './Listitem6.css';
import {Link, Outlet} from 'react-router-dom'

const Listitem6=()=>{
    return (
        <div className='listitem'>
            <Link to="/description3"><img src='https://ntvb.tmsimg.com/assets/p20145748_b_h8_aa.jpg?w=960&h=540' alt='' className='spider'/></Link>
            <Outlet/>
        </div>
    )
}
 
export default Listitem6;

