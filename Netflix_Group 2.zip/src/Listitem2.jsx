import React from 'react';
import ReactDOM from 'react-dom';
import {Link, Outlet} from 'react-router-dom';
import './Home.css';
import './Listitem2.css';
 
const Listitem2=()=>{
    return (
        <div className='listitem'>
            <Link to="/description"><img src='https://images-na.ssl-images-amazon.com/images/S/pv-target-images/18dbce6a92f8b83aed0b55eccbf99bf397b556e83914bbed8a69acebaa4cd7d6._RI_V_TTW_.jpg' alt='' className='spider'/></Link>
            <Outlet/>
        </div>
    )
}
 
export default Listitem2;

