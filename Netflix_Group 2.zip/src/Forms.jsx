import React, { useState } from 'react';
import ReactDOM from 'react-dom';
const Forms=()=>{
    const[myinfo,setMyinfo]=useState({
        fname:"",
        mobile:"",
        gender:"",
        language:""
    });
 
    const onSubmits=(event)=>{
        event.preventDefault();
        alert("Thank you for submitting");
    }
    const inputHandler=(event)=>{
        console.log(event.target.value)
        //setName(event.target.value)
    console.log(event.target.name)
    console.log(event.target.placeholder)
    const value=event.target.value;
    const name=event.target.name;
    setMyinfo((preValue)=>{
        // setMyinfo({ ...preValue,
        // [name]:value})
        // ...preValue,
        // [name]=value
        return{
            ...preValue,
            [name]:value,
        }
    });
}
return(
<>
<form onSubmit={onSubmits}>
 
    <table>
        <tr>
            <td>Enter Name</td>
            <td>
                <input type="text"
                placeholder="Enter Your Name"
                name="fname"
                onChange={inputHandler}
                 value={myinfo.fname}/>
                 <br></br>
            </td>
        </tr>
 
        <tr>
            <td>Enter Number</td>
            <td>
                <input type="text"
                placeholder="Enter Your Mobile Number"
                name="mobile"
                onChange={inputHandler}
                 value={myinfo.mobile}/>
                 <br></br>
            </td>
        </tr>
 
        <tr>
            <td>Enter Gender</td>
            <td>
                <input type="radio"
                name="gender"
                value="Male"
                onChange={inputHandler}
                />Male<br></br>
 
                <input type="radio"
                name="gender"
                value="Female"
                onChange={inputHandler}
                />Female
                <br></br>
               
            </td>
        </tr>
 
        <tr>
            <td>Enter Language:</td>
            <td>
            <input type="text"
                placeholder="Enter Language"
                name="language"
                onChange={inputHandler}
                 value={myinfo.language}/>
                 <br></br>
 
               
            </td>
        </tr>
       
</table>
   
    <button type="submit">Click Me</button>
 
 
    <h2>Name: {myinfo.fname}</h2>
    <h2>Mobile Number: {myinfo.mobile}</h2>
    <h2>Gender: {myinfo.gender}</h2>
    <h2>Languages: {myinfo.language}</h2>
    </form>
</>
    );
}
export default Forms;