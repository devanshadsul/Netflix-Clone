import './App.css';
import{BrowserRouter,Routes,Route} from 'react-router-dom'
import React from 'react';
import Register from './Register';
import Login from './Login';
import Home from './Home';
import Description from './Description';
import Description2 from './Description2';
import Description3 from './Description3';
 
function App(){ 
  return (
    <>
      <Routes>
          <Route index element={<Login/>} />
          <Route exact path="/" element={<Login/>} />
          <Route exact path="home" element={<Home/>} />
          <Route exact path="description2" element={<Description2/>} />
          <Route exact path="description" element={<Description/>} />
          <Route exact path="description3" element={<Description3/>} />
          <Route exact path="register" element={<Register/>} />

      </Routes>
    </>
  );
}
export default App;

