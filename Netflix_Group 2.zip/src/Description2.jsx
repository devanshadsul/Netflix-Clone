import './Description2.css'

import React from 'react';
import ReactDOM from 'react-dom';

import Navbar from './Navbar';
const Description2=()=>{
    return(
        <div className="main-containter">
            {/* <img src="https://images-na.ssl-images-amazon.com/images/S/pv-target-images/2476db59cb45005253032a577c62ab5fdfc90d62e3f6e9a471498595a4dac033._UY500_UX667_RI_V_TTW_.jpg"/> */}
            <div className="navbar">
                <Navbar/>
            </div>
            <div className="movieinfo">
                <h1> BRAHMASTRA
                    PART 1: SHIVA </h1>
                <div className="percent">
                    <h4> 92% match  &nbsp; &nbsp;</h4>
                    <span>2022</span>
                </div>
                <div className="buttons">
                    <button className='play'><img src='https://img.icons8.com/ios-glyphs/344/play--v1.png'alt='play'/>
                    <span className='spanplay'> &nbsp; Play</span>
                    </button>

                    <button className='more'><img src='https://img.icons8.com/ios-glyphs/344/plus-math.png' alt='info'/>
                    <span className='mylist'> &nbsp; My List</span>
                    </button>
 
                </div>
                <h3> Shiva, a DJ learns about his strange connection with the element of fire and 
                    <br/>also holds the power to awaken the Brahmastra, a supernatural weapon that is 
                    <br/>said to be able to destroy the universe, capable of destroying creation and vanquishing 
                    <br/>all beings. On the other hand, Junoon, the queen of dark forces is also on a 
                    <br/>quest to get hold of the Brahmastra.</h3>
                <p> Cast: Ranbir Kapoor, Alia Bhat, Mouni Roy<br/>
                Director: Ayan Mukherjee</p>
<br/>
                <div className="rate">
                    <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/126/126473.png'alt='play'/>
                    </button> <button className='more'><img src='https://cdn-icons-png.flaticon.com/512/20/20661.png' alt='info'/>
                    </button>
                </div>

            </div>
        </div>
        
    )

}
export default Description2;





