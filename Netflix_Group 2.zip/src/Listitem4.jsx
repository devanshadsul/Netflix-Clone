import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './Listitem4.css';
import {Link, Outlet} from 'react-router-dom'

const Listitem4=()=>{
    return (
        <div className='listitem'>
             <img src='https://img1.hotstarext.com/image/upload/f_auto,t_web_m_1x/sources/r1/cms/prod/7527/177527-h' alt='' className='spider'/>
        </div>
    )
}
 
export default Listitem4;

