import React from 'react';
import ReactDOM from 'react-dom';
import { Link,Outlet } from 'react-router-dom';
import './Home.css';
import './Listitem.css';
 
const Listitem=()=>{
    return (
        <div className='listitem'>
          <Link to="/description2"> <img src='https://images.hindustantimes.com/img/2021/12/14/1600x900/brahmastra_1639470083860_1639470092344.PNG' alt='' className='spider'/></Link>
          <Outlet/>
        </div>
    )
}
 
export default Listitem;

