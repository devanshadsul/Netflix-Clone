import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './Navbar.css';
import {Link , Outlet} from 'react-router-dom'
 
const Navbar=()=>{
    return (
        <div className='navbar'>
            <div className="container">
                <div className="left">
                    <img src="https://www.freepnglogos.com/uploads/netflix-logo-0.png" alt='logo' className='logo'/>
                    <span className='span'><Link className='linkcss' to="/home">Home</Link></span>
                    <span className='span'>Series</span>
                    <span className='span'>Movies</span>
                    <span className='span'>News and Popular</span>
                    <span className='span'><Link className='linkcss' to="/">Log Out</Link></span>
                    <Outlet/>
                </div>
                <div className="right">
                    <img src="https://www.freeiconspng.com/uploads/search-icon-png-2.png" alt='search' className='icon'/>
                    <img src="https://www.freeiconspng.com/uploads/bell-icon-8.png" alt='notification' className='icon'/>
                    <img src="https://www.freeiconspng.com/uploads/smiley-icon-1.png" alt='profile' className='profileicon'/>
 
 
                </div>
            </div>
        </div>
    )
}
 
export default Navbar;
