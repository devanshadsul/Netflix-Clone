
import React from 'react';
import ReactDOM from 'react-dom';
import './Home.css';
import './Movie.css';
 
 
const Movie=()=>{
    return (
        <div className='movie'>
            <img src='https://cdn.vox-cdn.com/thumbor/K4Fzm8J1vTz0tP5rsYanpA5VqhQ=/1400x788/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/22932138/the_batman_2022_movie_trailer.jpg' alt='poster' className='poster'/>
 
            <div className='info'>
                <img src='https://occ-0-1432-1433.1.nflxso.net/dnm/api/v6/LmEnxtiAuzezXBjYXPuDgfZ4zZQ/AAAABUZdeG1DrMstq-YKHZ-dA-cx2uQN_YbCYx7RABDk0y7F8ZK6nzgCz4bp5qJVgMizPbVpIvXrd4xMBQAuNe0xmuW2WjoeGMDn1cFO.webp?r=df1' alt='title' className='title'/>
                <span className="description">When a sadistic serial killer begins murdering key political figures in Gotham, Batman is forced to investigate the city's hidden corruption and question his family's involvement.</span>
               
                <div className="buttons">
                    <button className='play'><img src='https://www.freeiconspng.com/uploads/video-play-icon-6.png'alt='play'/>
                    <span className='spanplay'>Play</span>
                    </button>
 
                    <button className='more'><img src='https://www.freeiconspng.com/uploads/info-icon--6.png' alt='info'/>
                    <span>Info</span>
                    </button>
 
                </div>
            </div>
   
        </div>
    )
}
 
export default Movie;

